import os
import subprocess

def process_files(folder_path, jar_path):
    # Iterate over files in the folder
    for filename in os.listdir(folder_path):
        if os.path.isfile(os.path.join(folder_path, filename)):
            # Call the JAR file with the filename as parameter and capture the output            
            process = subprocess.run(["java", "-jar", jar_path, "filePath=" + os.path.join(folder_path, filename)], stdout=subprocess.PIPE, text=True)
            # Print the output of the JAR file
            print(process.stdout)

# Example usage:
folder_path = "files"
jar_path = "test.jar"
process_files(folder_path, jar_path)
